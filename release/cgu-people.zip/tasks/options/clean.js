module.exports = {
	main: ['release/<%= pkg.version %>']
};