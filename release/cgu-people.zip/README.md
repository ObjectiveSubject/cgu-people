# CGU People

**v1.0.0**

A plugin that add support for People to CGU Core themes.

Requires the [CGU Core theme](https://github.com/ObjectiveSubject/cgu-core).
